# Aplicación LectoGuard - Documentación


- [Aplicación LectoGuard - Documentación](#aplicación-lectoguard---documentación)
- [Contexto de la Aplicación - Analisis](#contexto-de-la-aplicación---analisis)
    - [Mundo real del problema](#mundo-real-del-problema)
    - [Apps existentes similares](#apps-existentes-similares)
    - [Por qué mi app es mejor](#por-qué-mi-app-es-mejor)
    - [Casos de Uso](#casos-de-uso)
    - [Requisitos Funcionales (F) y No Funcionales (NF)](#requisitos-funcionales-f-y-no-funcionales-nf)
      - [Funcionales:](#funcionales)
      - [No Funcionales:](#no-funcionales)
- [Diseño](#diseño)
  - [GUI (Interfaz Gráfica de Usuario)](#gui-interfaz-gráfica-de-usuario)
    - [UI (Vistas)](#ui-vistas)
      - [1. ActivityLogin:](#1-activitylogin)
      - [2. ActivitySignUp:](#2-activitysignup)
      - [3. ActivityHome:](#3-activityhome)
      - [4. ActivitySaveBook:](#4-activitysavebook)
      - [5. ActivityProfile:](#5-activityprofile)
      - [6. ActivitySavedBooks:](#6-activitysavedbooks)
    - [UX (Usabilidad)](#ux-usabilidad)
    - [Diagrama de Navegación](#diagrama-de-navegación)
  - [Arquitectura](#arquitectura)
    - [Despliegue](#despliegue)
    - [Componentes](#componentes)
    - [Base de datos](#base-de-datos)
    - [Plan de Pruebas](#plan-de-pruebas)
    - [Diagrama UML](#diagrama-uml)


# Contexto de la Aplicación - Analisis

### Mundo real del problema
`
La aplicación resuelve la necesidad de los amantes de la lectura de tener una app para descubrir, organizar y llevar un registro de los libros que quieren leer o han leído. Muchos lectores actualmente utilizan muchas plataformas sin un sistema unificado.
`

### Apps existentes similares
- Goodreads
- Wattpad
- Google Play Books
- Kindle

### Por qué mi app es mejor
1. Interfaz más simple y minimalista
2. Enfoque en la experiencia básica de guardar libros sin distracciones
3. Sistema de perfil personalizado con estadísticas sencillas
4. No incluye publicidad
5. Totalmente Gratuito

### Casos de Uso
1. Registro de nuevo usuario
    - Actor: Usuario no registrado
    - Flujo: Completa formulario → validación de datos → se crea la cuenta 
  
2. Inicio de sesión
   - Actor: Usuario registrado
   - Flujo: Introduce credenciales → se verifican → acceso concedido
  
3. Exploración de libros
   - Actor: Usuario autenticado
   - Flujo: Navega por lista → selecciona un libro → ve detalles
  
4. Guardar libro
   - Actor: Usuario autenticado
   - Flujo: Selecciona un libro → pulsa guardar → el libro se añade a su colección

5. Visualización de perfil
   - Actor: Usuario autenticado
   - Flujo: Accede a perfil → ve sus estadísticas

### Requisitos Funcionales (F) y No Funcionales (NF)

#### Funcionales:
- F1: El usuario debe poder registrarse con (email, nombre, teléfono y contraseña)
- F2: El usuario debe poder iniciar sesión con sus credenciales (email y contraseña)
- F3: El sistema debe mostrar una lista de libros disponibles
- F4: El usuario debe poder guardar libros en su colección
- F5: El sistema debe mostrar los libros guardados por el usuario
- F6: El sistema debe mostrar información del perfil del usuario

#### No Funcionales:
- NF1: La aplicación debe responder a las acciones del usuario
- NF2: Los datos del usuario deben almacenarse de forma segura
- NF3: La interfaz debe ser intuitiva
- NF4: La aplicación debe funcionar en la mayoria de versiones Android

# Diseño

## GUI (Interfaz Gráfica de Usuario)

### UI (Vistas)
#### 1. ActivityLogin:
`
Responsabilidad: Autenticación de usuarios.
`

Funciones clave:
- Mostrar campos de email y contraseña.
- Validar credenciales con la base de datos (Room).
- Navegar a:
  - HomeActivity (si login exitoso).
  - SignUpActivity (si el usuario elige registrarse).
- Cerrar la app con el botón Salir.
  `
  Campos: Email, Contraseña
  `
  `
  Botones: Iniciar Sesión, Registrarse, Salir
  `
<img src="https://i.imgur.com/vzy4zPA.png" alt="DiagramaUML" style="width: auto; height: 60%;">

#### 2. ActivitySignUp:
`
Responsabilidad: Registro de nuevos usuarios.
`

Funciones clave:
- Recoger datos: nombre, email, teléfono, contraseña.
- Validar campos (ej: formato de email, contraseña segura).
- Guardar usuario en Room Database.
- Redirigir a LoginActivity tras registro exitoso.
`
  Campos: Nombre, Email, Teléfono, Contraseña
`
`
  Botones: Registrarse, Cancelar
`
<img src="https://i.imgur.com/DQ3QDpc.png" alt="DiagramaUML" style="width: auto; height: 60%;">

#### 3. ActivityHome:
`
Responsabilidad: Pantalla principal con listado de libros.
`

Funciones clave:

- Mostrar mensaje de bienvenida con SharedPreferences.
- Contener un RecyclerView con libros disponibles (título + portada).
- Implementar Bottom Navigation para navegar a:
- SavedBooksActivity (Guardados).
- ProfileActivity (Perfil).
- Navegar a SaveBookActivity al seleccionar un libro.
`
TextView: "Bienvenido, [Nombre]"
`
`
RecyclerView: Lista de libros (imagen + título)
`
`
Bottom Navigation: Guardados, Inicio, Perfil
`
<img src="https://i.imgur.com/rONGonT.png" alt="DiagramaUML" style="width: auto; height: 60%;">

#### 4. ActivitySaveBook:
`
Responsabilidad: Detalle y almacenamiento de un libro.
`
Funciones clave:

- Mostrar portada y título del libro seleccionado.
- Guardar libro en la BD (tabla UserBook) al pulsar Guardar.
- Volver a HomeActivity al cancelar.
`
ImageView: Portada del libro
`
`
TextView: Título del libro
`
`
Botones: Guardar, Salir
`
<img src="https://i.imgur.com/b0vlckP.png" alt="DiagramaUML" style="width: auto; height: 60%;">

#### 5. ActivityProfile:
`
Responsabilidad: Mostrar información del usuario.
`
Funciones clave:

- Mostrar datos: email, teléfono, fecha de registro, libros guardados (consulta a BD).
- Botón Cerrar sesión.
- Bottom Navigation (igual que HomeActivity).
`
TextViews: Email, Teléfono, Fecha Alta, Libros Guardados
`
`
Botón: Cerrar Sesión
`
`
Bottom Navigation: Guardados, Inicio, Perfil
`

<img src="https://i.imgur.com/mPcYyFs.png" alt="DiagramaUML" style="width: auto; height: 60%;">

#### 6. ActivitySavedBooks:
`
Responsabilidad: Listar libros guardados por el usuario.
`
Funciones clave:
- Mostrar RecyclerView con libros guardados (consulta a BD).
- Bottom Navigation (igual que HomeActivity).
`
TextView: "Libros Guardados:"
`
`
RecyclerView: Lista de libros guardados
`
`
Bottom Navigation: Guardados, Inicio, Perfil
`
<img src="https://i.imgur.com/riQ5uQ1.png" alt="DiagramaUML" style="width: auto; height: 60%;">

### UX (Usabilidad)
- Navegación consistente con el bottom navigation
- Feedback visual al realizar acciones (guardar libro, etc.)
- Validación de formularios en tiempo real
- Mensajes de error claros
- Diseño User Friendly
  
### Diagrama de Navegación
<img src="https://i.imgur.com/myJjXGv.png" alt="DiagramaUML" style="width: auto; height: 60%;">

## Arquitectura

### Despliegue

- Aplicación móvil Android
- Base de datos local SQLite con Room
- Posible futura integración con Firebase para sincronización en la nube


### Componentes

- Activities: Login, SignUp, Home, SaveBook, Profile, SavedBooks
- Fragmentos: BottomNavigation, BookItem, UserInfo
- ViewModels: UserViewModel, BookViewModel
- Repositorios: UserRepository, BookRepository
- Base de datos: Entidades User y Book, DAOs correspondientes


### Base de datos

- Tabla User:
  - id (PK)
  - name
  - email
  - phone
  - password
  - signupDate

- Tabla Book:
  - id (PK)
  - title
  - coverImage 

- Tabla UserBook (relación muchos a muchos):
  - userId (FK)
  - bookId (FK)
  - savedDate
  
### Plan de Pruebas
- Pruebas unitarias:
  - Validación de formularios
  - Operaciones de base de datos
  - Lógica de negocio

- Pruebas de UI:
  - Flujo de navegación
  - Comportamiento del RecyclerView
  - Interacción con botones

- Pruebas manuales:
  - Casos de uso principales
  
### Diagrama UML
<img src="https://i.imgur.com/9CHsZYZ.png" alt="DiagramaUML" style="width: auto; height: 60%;">

*Aviso: Ciertas funcionalidades o implementaciones de las cuales se nombran pueden ser descartadas o implementadas con una funcionalidad limitada y meramente demonstrativa*